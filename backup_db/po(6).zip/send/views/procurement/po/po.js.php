<script>
    jQuery(document).ready(function () {
		ComponentsDateTimePickers.init();

    });
    btnStart();

</script>