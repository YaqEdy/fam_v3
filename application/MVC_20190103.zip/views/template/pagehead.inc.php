<!-- BEGIN PAGE HEAD
<div class="page-head">
     BEGIN PAGE TITLE 
    <div class="page-title">
        <h1>Dashboard
            <small>dashboard & statistics</small>
        </h1>
    </div>
     END PAGE TITLE 
     BEGIN PAGE TOOLBAR 
    <div class="page-toolbar">

         BEGIN THEME PANEL 
        <div class="btn-group btn-theme-panel">
            <a href="javascript:;" class="btn dropdown-toggle" data-toggle="dropdown">
                <i class="icon-settings"></i>
            </a>

        </div>
         END THEME PANEL 
    </div>
     END PAGE TOOLBAR 
</div>
 END PAGE HEAD
 BEGIN PAGE BREADCRUMB 
<ul class="page-breadcrumb breadcrumb">
    <li>
        <a href="index.html">Home</a>
        <i class="fa fa-circle"></i>
    </li>
    <li>
        <span class="active">Dashboard</span>
    </li>
</ul>
 END PAGE BREADCRUMB -->