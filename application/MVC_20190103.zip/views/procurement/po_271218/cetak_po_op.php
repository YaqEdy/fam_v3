
<style >
    
table, tr, td {
    border-collapse:collapse;
    border:1px solid #999;
    font-family:Tahoma, Geneva, sans-serif;
    font-size:12px;
}



</style>

<div class="row">
    <div class="col-md-12">
        <!-- BEGIN VALIDATION STATES-->
        <div class="portlet light portlet-fit  bordered">
            <div class="portlet-title">
                <div class="caption">
                   
                </div>
                <div class="portlet-body">



                <!-- ===================================================== -->

                 <div class="col-md-12">

                    <table class="table table-striped table-bordered table-hover text_kanan" height="100px" right="100px" align="right" border="1">
                        <tr>
                            <td colspan="4" >&nbsp;Purchase Order No&nbsp;</td>
                            <td colspan="2" >&nbsp;PO0000000000001326&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="4" >&nbsp;-&nbsp;</td>
                            <td colspan="2" >&nbsp;-&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="4" >&nbsp;Date&nbsp;</td>
                            <td colspan="2" >&nbsp;24/09/2018&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="4" >&nbsp;-&nbsp;</td>
                            <td colspan="2" >&nbsp;-&nbsp;</td>
                        </tr>
                    </table>
                </div>
                           
                           
                           
                <!-- ======================================================== -->


              
                          
                            <img src="<?php echo base_url('metronic/img/logo.png'); ?>" alt="gambar duniailkom" width="120px"  height="60px"
                            align="left"/>
                    <br>
                    <br>
                    <br>
                    <br>
                            <caption> Gedung Artdaloka Lantai 1,6&10 <br> Jl.Jend. Sudirman Kav.2 Jakarta DKI 10220</caption>
                                
                     
                    <br>
                    <br>
                    <br>
                 




                    <!-- ====================================================== -->
                <div class="col-md-12">
                <!-- Vendor : -->
                    <table  height="100px" right="100px" align="left" border="1">
                    <caption> Vendor :</caption>
                        <tr>
                                <td width="300px" height="20px" colspan="1" >&nbsp;CENTRAL SUKSES MANDIRI,<br> &nbsp;PT GLODOK PLAZA LT.2 BLOK B NO.12 A <br> &nbsp;JAKARTA BARAT</td>
                               
                                <!-- <td colspan="10" ><br><br><br><br></td>
                                <td colspan="1" ><br><br><br><br><br></td> -->
                            </tr>
                    </table>
                </div>

                <div class="col-md-12">
                <!-- Ship To : -->
                    <table  height="100px" right="100px" align="right" border="1">
                    <caption> Ship To :</caption>
                        <tr>
                                <td width="300px" height="20px" colspan="1" >&nbsp;Address listed witd item below&nbsp;</td>
                               
                                <!-- <td colspan="10" ><br><br><br><br></td>
                                <td colspan="1" ><br><br><br><br><br></td> -->
                            </tr>
                    </table>
                </div>
                <br>
                <br>
                <br>
                 <br>
                <br>
                <br>
                 <br>
                <br>
                <br>
                           
                           
                       



                    <div class="col-md-12">
                        <caption> Contract Number :</caption>
                    </div>
                    <div class="col-md-12">
                        <caption> * Change Since the Previous Revision</caption>
                    </div>
                    <br>
                    <div class="col-md-12">
                        <table class="table " height="300px" width="1000px"  border="1">
                            <tr>
                                <th colspan="2" >&nbsp;Shipping Method&nbsp;</th>
                                <th colspan="2" >&nbsp;Payment Terma&nbsp;</th>
                                <th colspan="2" >&nbsp;Confirm With&nbsp;</th>
                                <th colspan="1" >&nbsp;Page&nbsp;</th>
                            </tr>
                             <tr>
                                <td colspan="2" ></td>
                                <td colspan="2" >&nbsp;14</td>
                                <td colspan="2" ></td>
                                <td colspan="1" >&nbsp;1</td>
                            </tr>
                             <tr>
                                <th colspan="1" >&nbsp;L/N  Item Number</th>
                                <th colspan="1" >Description</th>
                                <th colspan="1" >Req. Data</th>
                                <th colspan="1" >U/M</th>
                                <th colspan="1" >Ordered</th>
                                <th colspan="1" >Unit Price</th>
                                <th colspan="1" >Ext.Price</th>
                            </tr>
                            <tr>
                                <th colspan="1" >Shipping Method</th>
                                <th colspan="1" >Reference Number</th>
                                <th colspan="1" >FOB</th>
                                <th colspan="4" ></th>
                            </tr>
                            <tr>
                                <td colspan="1" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  1. Printer Epson L120 </td>
                                <td colspan="1" ></td>
                                <td colspan="1" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;03/10/2018</td>
                                <td colspan="1" >&nbsp;QTY</td>
                                <td colspan="1" >&nbsp;1</td>
                                <td colspan="1" >&nbsp;Rp.1.500.000,00&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td>
                                <td colspan="1" >&nbsp;Rp.1.500.000,00</td>
                            </tr>
                             <tr>
                                <td colspan="1" >&nbsp;DELIVERY</td>
                                <td colspan="1" >&nbsp;PRINTER EPSON L120</td>
                                <td colspan="1" >&nbsp;NONE</td>
                                <td colspan="1" >&nbsp;</td>
                                <td colspan="1" >&nbsp;</td>
                                <td colspan="1" >&nbsp;</td>
                                <td colspan="1" >&nbsp;</td>
                            </tr>
                            <tr>
                                <td  height="100px" colspan="1" >&nbsp;Deliver To :</td>
                                <td  height="20px" colspan="1" >&nbsp;PT PNM Persero<br>&nbsp;Gedung Artdaloka Lantai 1,6&10 <br>&nbsp;Jl.Jend. Sudirman Kav.2 <br>&nbsp;Jakarta DKI 10220</td>
                                <td  height="20px" colspan="1" >&nbsp;</td>
                                <td  height="20px" colspan="1" >&nbsp;</td>
                                <td  height="20px" colspan="1" >&nbsp;</td>
                                <td  height="20px" colspan="1" >&nbsp;</td>
                                <td  height="20px" colspan="1" >&nbsp;</td>
                            </tr>
                            
                        </table>
                    </div>
                    <br>
                   

                        <div class="col-md-12">

                            <table class="table " height="150px" width="300px" align="right" border="1">
                                <tr>
                                    <td bgcolor="#00ff80">&nbsp;Subtotal</td>
                                    <td> &nbsp;Rp.1.500.000,00&nbsp;</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#00ff80">&nbsp;Trade Discount&nbsp;</td>
                                    <td> &nbsp;Rp.0,00</td>
                                </tr>
                                 <tr>
                                    <td bgcolor="#00ff80">&nbsp;Freight</td>
                                    <td>&nbsp;Rp.0,00 </td>
                                </tr>
                               <tr>
                                    <td bgcolor="#00ff80">&nbsp;Miscellaneous</td>
                                    <td>&nbsp;Rp.0,00</td>
                                </tr>
                                <tr>
                                    <td bgcolor="#00ff80">&nbsp;Tax</td>
                                    <td>&nbsp;Rp.150.000,00&nbsp; </td>
                                </tr>
                                <tr>
                                    <td bgcolor="#00ff80">&nbsp;Order Total </td>
                                    <td>&nbsp;Rp.1.650.000,00 &nbsp;</td>
                                </tr>
                            </table>
                        </div>

                           
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>
                            <br>

                            <hr width="25%" align="left" color="black">
                            <caption> Kepala Divisi PPI</caption>
                        

                       
                         <div class="col-md-12">
                          <br>
                        
                            <caption> PT.PERMODALAN NASIONAL MADANI (PERSERO)</caption>
                         </div>

                          <div class="col-md-12">
                            <caption> Kantor Pusat : Menara Taspen Lt.1,2,6,7,10,13 Jl.Jend.Sudirman Kav.2-Jakarta 10220 Indonesia Telp. (62-21)2511405 Email : madani@pnm.co.id http://www.pnm.co.id</caption>
                         </div>
                       

                        



    </div>
    </div>
    </div>
    <!-- END VALIDATION STATES-->
</div>
</div>





<!-- <?php $tdis->load->view('app.min.inc.php'); ?>
<?php $tdis->load->view('procurement/hps/hps.js.php'); ?> -->

<script>
    window.print();
</script> 