<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Konfigurasi_menu_status_user_m extends CI_Model {

    public function get_status_user() {
        $rows = array(); //will hold all results
        $sql = "select * from sec_usergroup order by usergroup_id asc ";
        $query = $this->db->query($sql);
        foreach ($query->result_array() as $row) {
            $rows[] = $row; //add the fetched result to the result array;
        }
        return $rows; // returning rows, not row
    }
    
    public function update_menu_status_user_m($data_menu, $status_user) {
        //remove menu allowed berdasarkan status usernya
        $allowed = '+' . $status_user;
        $sqlgetmenu = "select menu_id,menu_allowed from sec_menu where menu_allowed like '%" . $allowed . "%'";
        $querygetmenu = $this->db->query($sqlgetmenu);
        $resltgetmenu = $querygetmenu->result();
        foreach ($resltgetmenu as $keywordgetmenu) {
            $allowed_new = '';
            $menu_alowedgetmenu = $keywordgetmenu->menu_allowed;
            $menu_idgetmenu = $keywordgetmenu->menu_id;
            $menu_alowed2 = explode('+', $menu_alowedgetmenu);
            foreach ($menu_alowed2 as $keyword) {
                if ((strlen(trim($keyword)) != 0) && ($keyword != $status_user)) {
                    $allowed_new = $allowed_new . '+' . $keyword;
                }
            }
            $sql = "update sec_menu set menu_allowed = '" . $allowed_new . "' where menu_id = '" . $menu_idgetmenu . "'";
            $this->db->query($sql);
        }


        foreach ($data_menu as $menu_id) {
            //update child
            $sql0 = "select menu_allowed,parent,lvl from sec_menu where menu_id = '" . $menu_id . "'";
            $query0 = $this->db->query($sql0);
            $reslt = $query0->result();
            $menu_alowed = $reslt[0]->menu_allowed;
            $menuid = $reslt[0]->parent;
            $sql1 = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed . "') where menu_id = '" . $menu_id . "' and menu_uri <> '#'";
            $query1 = $this->db->query($sql1);
            
            //update parent
            $lvl = $reslt[0]->lvl;
            if ($lvl > 0) {
                for ($i = 1; $i <= $lvl; $i++) {
                    $allowed4 = '';
                    $count = 0;
                    $sql0 = "select menu_allowed,parent from sec_menu where menu_id = '" . $menuid . "'";
                    $query0 = $this->db->query($sql0);
                    $reslt = $query0->result();
                    $menu_alowed = $reslt[0]->menu_allowed;
                    $menu_alowed3 = explode('+', $menu_alowed);
                    foreach ($menu_alowed3 as $keyword3) {
                        if ($keyword3 == $status_user) {
                            $count = $count + 1;
                        }
                    }
                    if ($count == '0') {
                        $sql2 = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed . "') where menu_id = '" . $menuid . "'";
                        $query1 = $this->db->query($sql2);
                    }
                    $menuid = $reslt[0]->parent;
                } 
            }
        }
        // die();
        return true;
        /*
          foreach ($data_menu as $x => $x_value) {

          $data_menu2 = array();
          $data_menu2 = explode('_', $x_value);
          foreach ($data_menu2 as $y => $y_value) {
          $sql0 = "select menu_allowed from sec_menu where menu_id = '" . $y_value . "'";
          $query0 = $this->db->query($sql0);
          $menu_alowed = $query0->result();
          $menu_alowed = $menu_alowed[0]->menu_allowed;
          if (!strpos($menu_alowed, $status_user)) {
          $sql = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed_new . "') where menu_id = '" . $y_value . "'";
          $query = $this->db->query($sql);
          }
          }
          }// end foreach($data_menu as $x=>$x_value){
         * */
    }

    public function update_menu_status_user_m_lama($data_menu, $status_user) {

   
//      
        if (empty($data_menu[0])) {
            return false;
        } else {
            $allowed_new = '+' . $status_user.'+';

            $sql = "update sec_menu set menu_allowed = replace(menu_allowed,'" . $allowed_new . "','')"; // hilangkan semua
//            die($sql);
            $query = $this->db->query($sql);

            foreach ($data_menu as $x => $x_value) {
                $data_menu2 = array();

                $data_menu2 = explode('_', $x_value);
 
                if (count($data_menu2) > 1) {

                    $sql1 = "select menu_allowed,parent,menu_id from sec_menu where menu_id = " . $data_menu2[0];
                    $query1 = $this->db->query($sql1)->result();

                    foreach ($query1 as $valSub) {
                       
                        $menu_id = $valSub->menu_id;
                        $parent = $valSub->parent;
                        $sqll = "  SELECT count(*) as jml FROM sec_menu WHERE menu_id = " . $menu_id . " AND menu_allowed LIKE '%" . $allowed_new . "%'";
                        $cekAllow = $this->db->query($sqll)->result();

                        if ($cekAllow[0]->jml < 1) {
//                            LEVEL 4
                            $sqlupd = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed_new . "') where menu_id = " . $menu_id;
                            $queryupd = $this->db->query($sqlupd);

                            $sqlparentsubparent = "SELECT count(*) as jml  FROM sec_menu WHERE menu_id = " . $parent . " AND menu_allowed LIKE '%" . $allowed_new . "%'";
                            $cekAllowsubparent = $this->db->query($sqlparentsubparent)->result();


                            if ($cekAllowsubparent[0]->jml < 1) {
                                //LEVEL 3
                                $sqlupd1 = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed_new . "') where menu_id = " . $parent;
                                $queryupd1 = $this->db->query($sqlupd1);
                            }


                            //LEVEL 2
                            $sql2 = "select parent from sec_menu where menu_id = '" . $parent . "'";
                            $query2 = $this->db->query($sql2)->result();

                            $sqlparent = "SELECT count(*) as jml  FROM sec_menu WHERE menu_id = " . $query2[0]->parent . " AND menu_allowed LIKE '%" . $allowed_new . "%'";
                            $cekAllowparent = $this->db->query($sqlparent)->result();

                            if ($cekAllowparent[0]->jml < 1) {

                                $sqlsb2 = "select parent from sec_menu where menu_id = '" . $query2[0]->parent . "'";
                                $querysb2 = $this->db->query($sqlsb2)->result();

                                if (sizeof($querysb2) > 0) {
                                    $sqlparent2 = "SELECT count(*) as jml  FROM sec_menu WHERE menu_id = " . $querysb2[0]->parent . " AND menu_allowed LIKE '%" . $allowed_new . "%'";
                                    $cekAllowparent2 = $this->db->query($sqlparent2)->result();

                                    if ($cekAllowparent2[0]->jml < 1) {
                                        foreach ($querysb2 as $valParent2) {
                                            $sql2 = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed_new . "') where menu_id = " . $valParent2->parent;
                                            $this->db->query($sql2);
//                                    dd($query2);
                                        }
                                    }
                                }

                                foreach ($query2 as $valParent) {
                                    $sql2 = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed_new . "') where menu_id = " . $valParent->parent;
                                    $this->db->query($sql2);
//                                    dd($query2);
                                }
                            }
                            //LEVEL 1
                        }
                    }
                } else {
                     
                    foreach ($data_menu2 as $rows) {
                        
                        $sqlparentone = "SELECT count(*) as jml  FROM sec_menu WHERE menu_id = " . $rows . " AND menu_allowed LIKE '%" . $allowed_new . "%'";
                       
                        $cekAllowparentone = $this->db->query($sqlparentone)->result();
                        
//                         print_r($cekAllowparentone[0]->jml);die();
                        
                        if ($cekAllowparentone[0]->jml < 1) {
                            $sqlone = "update sec_menu set menu_allowed = concat(menu_allowed,'" . $allowed_new . "') where menu_id = '" . $rows . "'";
                            $query = $this->db->query($sqlone);
                        }
                    }
                }
            }// end foreach($data_menu as $x=>$x_value){

            return true;
        }
    }

    public function get_menu_group_user_m($kd_group_user,$userid=null) {
          
        if($userid!='')
        {
            $selectmenuid ="SELECT * FROM sec_menu_akses
                            JOIN users ON users.userid =sec_menu_akses.userid
                            WHERE users.userid =$userid  AND users.roles ='$kd_group_user'";

//            $selectmenuid ="SELECT * FROM sec_menu_akses
//                            JOIN users ON users.userid =sec_menu_akses.userid
//                            WHERE users.userid =$userid";
            $exe =$this->db->query($selectmenuid)->result();


        }else{
            $exe =[];
        }
    


        if(count($exe)>0)
        {

            $getMenu =$exe[0]->menu_id;
            $sql = "SELECT menu_id,parent,menu_allowed,lvl
                    FROM sec_menu 
                    WHERE menu_id IN ($getMenu)  AND menu_uri NOT IN ('#','-')";
        }else{
             
            $getMenu =null;
//            $sql = "SELECT menu_id,parent,menu_allowed,lvl
//                    FROM sec_menu
//                     WHERE menu_allowed LIKE '%+$kd_group_user%'";
            $sql = "SELECT menu_id,parent,menu_allowed,lvl
                    FROM sec_menu
                     WHERE menu_allowed LIKE '%+$kd_group_user%' AND  menu_uri NOT IN ('#','-')";

        }

        $query=$this->db->query($sql)->result();
      
//         $this->output->set_output($query);
//        dd($query);
        return $query;
    }

    public function update_level() {
        //$sqlalter = "ALTER TABLE sec_menu ADD lvl tinyint(4) NOT NULL DEFAULT '0';";
        //$query_alter = $this->db->query($sqlalter);
        $sqlx = "update sec_menu set lvl= 2 where menu_uri <> '#'";
        $queryx = $this->db->query($sqlx);
        $sql = "select menu_id,parent from sec_menu where menu_uri ='#' and parent = '0'";
        $query = $this->db->query($sql);
        $rows = $query->result();
        foreach ($rows as $row) {
            $sql2 = "select menu_id,parent from sec_menu where parent ='$row->menu_id' ";
            $query2 = $this->db->query($sql2);
            $rows2 = $query2->result();
            foreach ($rows2 as $row2) {
                $sql3 = "update sec_menu set lvl = 1 where menu_id = '$row2->menu_id'";
                $query3 = $this->db->query($sql3);
            }
        }
    }

}

/* End of file Konfigurasi_menu_status_user_m.php */
/* Location: ./application/models/master_nasabahmodel.php */