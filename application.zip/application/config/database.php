<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$active_group = 'config1';
$query_builder = TRUE;


//====== SQL Server ======
$db['config1']['hostname'] = '127.0.0.1';//'127.0.0.1:3306';//192.168.13.4 localhost:3306 192.168.13.4:3306
$db['config1']['username'] = 'sa'; //perumnas
$db['config1']['password'] = 'plokijuh';//mmsPNMonl1n3 plokijuh890-MNB plokijuh890-MNB perumnas
$db['config1']['database'] = 'FAM_V3';//FAMPNM asset-pnmTRIAL19022018
$db['config1']['dbdriver'] = 'sqlsrv';
$db['config1']['port'] = '1433';
$db['config1']['dbprefix'] = '';
$db['config1']['pconnect'] = TRUE;//////
$db['config1']['db_debug'] = TRUE;
$db['config1']['cache_on'] = FALSE;
$db['config1']['cachedir'] = '';
$db['config1']['char_set'] = 'utf8';  
$db['config1']['dbcollat'] = 'utf8_general_ci';
$db['config1']['swap_pre'] = '';
$db['config1']['autoinit'] = TRUE;



//$tnsname = '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = 10.61.3.53)(PORT = 1521))
//        (CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = PNMUAT)))';

//$db['oracle'] = array(
//	'dsn'	=> '',
//	'hostname' => "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.61.3.53)(PORT=1521))(CONNECT_DATA=(SID=PNMUAT)))",
//	'username' => 'XXMTM',
//	'password' => 'XXMTM',
//	'database' => 'PNMUAT',
//	'dbdriver' => 'oci8',
//	'dbprefix' => '',
//	'pconnect' => TRUE,
//	'db_debug' => TRUE,
//	'cache_on' => FALSE,
//	'cachedir' => '',
//	'char_set' => 'utf8',
//	'dbcollat' => 'utf8_general_ci',
//	'swap_pre' => '',
//	'encrypt' => FALSE,
//	'compress' => FALSE,
//	'stricton' => FALSE,
//	'failover' => array(),
//	'save_queries' => TRUE
//);
   
//$db['oracle']['hostname'] = '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=10.61.3.53)(PORT=1521))(CONNECT_DATA=(SID=PNMUAT)))';//'127.0.0.1:3306';//192.168.13.4 localhost:3306 192.168.13.4:3306
//$db['oracle']['username'] = 'XXMTM'; //perumnas
//$db['oracle']['password'] = 'XXMTM';//mmsPNMonl1n3 plokijuh890-MNB plokijuh890-MNB perumnas
//$db['oracle']['database'] = 'PNMUAT';//FAMPNM asset-pnmTRIAL19022018
//$db['oracle']['dbdriver'] = 'oci8';
//$db['oracle']['dbprefix'] = '';
//$db['oracle']['pconnect'] = TRUE;//////
//$db['oracle']['db_debug'] = TRUE;
//$db['oracle']['cache_on'] = FALSE;
//$db['oracle']['cachedir'] = '';
//$db['oracle']['char_set'] = 'utf8';  
//$db['oracle']['dbcollat'] = 'utf8_general_ci';
//$db['oracle']['swap_pre'] = '';
//$db['oracle']['autoinit'] = TRUE;


//$db['config1']['stricton'] = FALSE; 

//$active_group = "config1";
//$active_record = TRUE;
//$query_builder = TRUE;
//
//$db['config1']['dsn'] = "";
//$db['config1']['hostname'] = "localhost";
//$db['config1']['port'] = "5432";
//$db['config1']['username'] = "postgres";
//$db['config1']['database'] = "MBM_AMS";
//$db['config1']['password'] = "";
//$db['config1']['dbdriver'] = "postgre";
//$db['config1']['dbprefix'] = "";
//$db['config1']['pconnect'] = FALSE;
//$db['config1']['db_debug'] = TRUE;
//$db['config1']['cache_on'] = FALSE;
//$db['config1']['cachedir'] = "";
//$db['config1']['char_set'] = "utf8";
//$db['config1']['dbcollat'] = "utf8_general_ci";
//$db['config1']['swap_pre'] = '';
//$db['config1']['encrypt'] = FALSE;
//$db['config1']['compress'] = FALSE;
//$db['config1']['stricton'] = FALSE;
//$db['config1']['failover'] = array();
//$db['config1']['save_queries'] = TRUE;