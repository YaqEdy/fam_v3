<?php
/**
* 
*/
class Test extends MY_Controller
{

		
	function index($object)
	{
		print_r($object);
		
		return 'complete';
		
	}
}
